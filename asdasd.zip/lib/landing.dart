import 'package:flutter/material.dart';
import 'package:flutter_application_2/navi.dart';
import 'package:get/get.dart';
import 'dart:async';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  @override
  void initState() {
    Timer(Duration(seconds: 2), () {
      Get.to(NaviPage());
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      alignment: Alignment.center,
      children: [
        Container(
          color: Color.fromARGB(255, 97, 170, 230),
          child: Center(child: Text("앱 로딩 중~")),
        ),
        CircularProgressIndicator()
      ],
    ));
  }
}
