import 'dart:convert';

import 'package:flutter_application_2/firstPage.dart';
import 'package:flutter_application_2/loading.dart';
import 'package:flutter_application_2/secondPage.dart';
import 'package:flutter_application_2/thirdPage.dart';
import 'package:flutter_application_2/loading.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:geolocator/geolocator.dart';

import 'package:flutter_application_2/weather_model.dart';

import 'landing.dart';
import 'package:get/get.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Weather Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LandingPage(),
    );
  }
}
