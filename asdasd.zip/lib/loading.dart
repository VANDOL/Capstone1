import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart';
import 'package:timer_builder/timer_builder.dart';
import 'package:intl/intl.dart';
import 'dart:math' as Math;

class ConvGridGps {
  static const double RE = 6371.00877; // 지구 반경(km)
  static const double GRID = 5.0; // 격자 간격(km)
  static const double SLAT1 = 30.0; // 투영 위도1(degree)
  static const double SLAT2 = 60.0; // 투영 위도2(degree)
  static const double OLON = 126.0; // 기준점 경도(degree)
  static const double OLAT = 38.0; // 기준점 위도(degree)
  static const double XO = 43; // 기준점 X좌표(GRID)
  static const double YO = 136; // 기1준점 Y좌표(GRID)

  static const double DEGRAD = Math.pi / 180.0;
  static const double RADDEG = 180.0 / Math.pi;

  static double get re => RE / GRID;

  static double get slat1 => SLAT1 * DEGRAD;

  static double get slat2 => SLAT2 * DEGRAD;

  static double get olon => OLON * DEGRAD;

  static double get olat => OLAT * DEGRAD;

  static double get snTmp =>
      Math.tan(Math.pi * 0.25 + slat2 * 0.5) /
      Math.tan(Math.pi * 0.25 + slat1 * 0.5);

  static double get sn =>
      Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(snTmp);

  static double get sfTmp => Math.tan(Math.pi * 0.25 + slat1 * 0.5);

  static double get sf => Math.pow(sfTmp, sn) * Math.cos(slat1) / sn;

  static double get roTmp => Math.tan(Math.pi * 0.25 + olat * 0.5);

  static double get ro => re * sf / Math.pow(roTmp, sn);

  static gridToGPS(int v1, int v2) {
    var rs = {};
    double theta;

    rs['x'] = v1;
    rs['y'] = v2;
    int xn = (v1 - XO).toInt();
    int yn = (ro - v2 + YO).toInt();
    var ra = Math.sqrt(xn * xn + yn * yn);
    if (sn < 0.0) ra = -ra;
    var alat = Math.pow((re * sf / ra), (1.0 / sn));
    alat = 2.0 * Math.atan(alat) - Math.pi * 0.5;

    if (xn.abs() <= 0.0) {
      theta = 0.0;
    } else {
      if (yn.abs() <= 0.0) {
        theta = Math.pi * 0.5;
        if (xn < 0.0) theta = -theta;
      } else
        theta = Math.atan2(xn, yn);
    }
    var alon = theta / sn + olon;
    rs['lat'] = alat * RADDEG;
    rs['lng'] = alon * RADDEG;

    return rs;
  }

  static gpsToGRID(double v1, double v2) {
    var xy = [0, 0];
    double theta;

    //rs['lat'] = v1;
    //rs['lng'] = v2;
    var ra = Math.tan(Math.pi * 0.25 + (v1) * DEGRAD * 0.5);
    ra = re * sf / Math.pow(ra, sn);
    theta = v2 * DEGRAD - olon;
    if (theta > Math.pi) theta -= 2.0 * Math.pi;
    if (theta < -Math.pi) theta += 2.0 * Math.pi;
    theta *= sn;
    xy[0] = (ra * Math.sin(theta) + XO + 0.5).floor();
    xy[1] = (ro - ra * Math.cos(theta) + YO + 0.5).floor();

    return xy;
  }
}

class Loading extends StatefulWidget {
  @override
  _LoadingState createState() => _LoadingState();
}

class _LoadingState extends State<Loading> with SingleTickerProviderStateMixin {
  int x = 1;
  int y = 1;
  String day = '';
  String time = '';
  var t1h;
  void initState() {
    super.initState();
    getLocation();
    getDayTime();
    api_convert();
    controller = TabController(length: 3, vsync: this);
  }

  late double longi;
  late double lati;
  late var a;
  var parsed_json;
  var bb;
  void getLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);

      longi = position.longitude;
      lati = position.latitude;

      print(position);
      var ddd = ConvGridGps.gpsToGRID(lati, longi);
      print(ddd);
      x = ddd[0];
      y = ddd[1];
    } catch (e) {
      print('There was a problem with the internet connection.');
    }

    var now = DateTime.now();
    String day = DateFormat('yyyyMMdd').format(now);
    String time = DateFormat('HHmm').format(now);

    //String abcd = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtFcst?serviceKey=eFyj3ueBq5sCbBFscragz%2B1M3OlYKNvJNqK94YCpxqrcZzhz%2BRY62m3vDSdgKAIW%2FzN0SNKjb47FssGnIrN7Yg%3D%3D&numOfRows=10&pageNo=1&base_date=20221114&base_time=0600&nx=55&ny=127&dataType=JSON';
    String temp =
        'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtFcst?serviceKey=eFyj3ueBq5sCbBFscragz%2B1M3OlYKNvJNqK94YCpxqrcZzhz%2BRY62m3vDSdgKAIW%2FzN0SNKjb47FssGnIrN7Yg%3D%3D&numOfRows=100&pageNo=1&base_date=20221114&base_time=2300&nx=$x&ny=$y&dataType=JSON';
    Response response = await get(Uri.parse(temp));
    String jsonData = response.body;
    var parsingData = jsonDecode(jsonData);

    print(temp);
    print(response.statusCode);
    print(response.body);
    //a = response.body;
    int totalCount = parsingData['response']['body']['totalCount'];

    for (int i = 0; i < totalCount; i++) {
      parsed_json = parsingData['response']['body']['items']['item'][i];

      if (parsed_json['category'] == '0500') {
        t1h = parsed_json['nx'];
        //bb = parsed_json['nx'];
      }
    }
  }

  void api_convert() async {
    var gpsToGridData = ConvGridGps.gpsToGRID(35.144631, 129.035714);
  }

  void getDayTime() async {
    var now = DateTime.now();
    day = DateFormat('yyyyMMdd').format(now);
    time = DateFormat('HHmm').format(now);
    print(day);
    print(time);
  }

  late TabController controller;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: Column(
      children: [
        SizedBox(height: 100),
        //Text('실제 위도 : $lati'),
        //Text('실제 경도 : $longi'),
        //Text('기상청 API 좌표 : $x, $y'),
        //Text('$day 현재시간: $time'),
        Text('t1h'),
        SizedBox(height: 50),
        ElevatedButton(
            onPressed: () {
              getLocation();
            },
            child: Text('gggg'))
        //Text('$bb')
      ],
    )));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}
