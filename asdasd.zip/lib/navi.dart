import 'package:flutter/material.dart';
import 'package:flutter_application_2/firstPage.dart';
import 'package:flutter_application_2/secondPage.dart';
import 'package:flutter_application_2/thirdPage.dart';

class NaviPage extends StatefulWidget {
  @override
  _NaviPageState createState() => _NaviPageState();
}

class _NaviPageState extends State<NaviPage> {
  int _selectedIndex = 1;
  List<BottomNavigationBarItem> bottomItems = [
    BottomNavigationBarItem(
      label: '1번',
      icon: Icon(Icons.favorite),
    ),
    BottomNavigationBarItem(
      label: '2번',
      icon: Icon(Icons.sunny),
    ),
    BottomNavigationBarItem(
      label: '3번',
      icon: Icon(Icons.cloud),
    ),
  ];
  List pages = [
    FirstPage(),
    SecondPage(),
    ThirdPage(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey.withOpacity(.60),
        selectedFontSize: 14,
        unselectedFontSize: 10,
        currentIndex: _selectedIndex,
        //showSelectedLabels: false,
        //showUnselectedLabels: false,
        onTap: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: bottomItems,
      ),
      body: pages[_selectedIndex],
    );
  }
}
